#!/bin/bash

find . -name '.DS_Store*' -exec rm -rf {} \;
find . -name 'xcuserdata*' -exec rm -rf {} \;

