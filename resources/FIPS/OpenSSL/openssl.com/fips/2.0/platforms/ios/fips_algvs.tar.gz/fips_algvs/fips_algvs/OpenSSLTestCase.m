//
//  OpenSSLTestCase.m
//  FIPS_test_suite
/* ====================================================================
 * Copyright (c) 2011 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.openssl.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    openssl-core@openssl.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.openssl.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* ====================================================================
 * Copyright 2011 Thursby Software Systems, Inc. All rights reserved.
 *
 * The portions of the attached software ("Contribution") is developed by
 * Thursby Software Systems, Inc and is licensed pursuant to the OpenSSL
 * open source license.
 *
 * The Contribution, originally written by Paul W. Nelson of
 * Thursby Software Systems, Inc, consists of the fingerprint calculation
 * required for the FIPS140 integrity check.
 *
 * No patent licenses or other rights except those expressly stated in
 * the OpenSSL open source license shall be deemed granted or received
 * expressly, by implication, estoppel, or otherwise.
 *
 * No assurances are provided by Thursby that the Contribution does not
 * infringe the patent or other intellectual property rights of any third
 * party or that the license provides you with all the necessary rights
 * to make use of the Contribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. IN
 * ADDITION TO THE DISCLAIMERS INCLUDED IN THE LICENSE, THURSBY
 * SPECIFICALLY DISCLAIMS ANY LIABILITY FOR CLAIMS BROUGHT BY YOU OR ANY
 * OTHER ENTITY BASED ON INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS OR
 * OTHERWISE.
 */

#import "OpenSSLTestCase.h"
//#import "OpenSSLTestCases.h"
#include "TestMessageQueue.h"
#import "ViewController.h"
#include <fcntl.h>

@interface OpenSSLTestCase ()
- (void)signal:(int)inSignal info:(struct __siginfo*)inInfo;
@end

@implementation OpenSSLTestCase

@synthesize delegate;
@synthesize screenQueue;
@synthesize title;
@synthesize argumentString;
@synthesize argumentPlaceholder;
@synthesize terminalOutputFileName;

static OpenSSLTestCase* testcase_handler = nil;

-(void)writeToStdout:(NSData*)inData
{
    int fd = open( [self.terminalOutputFileName fileSystemRepresentation], O_WRONLY|O_APPEND );
    if( fd < 0 )
        fd = open( [self.terminalOutputFileName fileSystemRepresentation], O_WRONLY|O_CREAT, 0644 ); 
    if( fd >= 0 )
    {
        write(fd, [inData bytes], inData.length );
        close(fd);
    }
    [self.screenQueue queueData:inData];
}

-(void)writeToStderr:(NSData*)inData
{
    int fd = open( [self.terminalOutputFileName fileSystemRepresentation], O_WRONLY|O_APPEND );
    if( fd < 0 )
        fd = open( [self.terminalOutputFileName fileSystemRepresentation], O_WRONLY|O_CREAT, 0644 ); 
    if( fd >= 0 )
    {
        write(fd, [inData bytes], inData.length );
        close(fd);
    }
    [self.screenQueue queueData:inData];
}

-(void)putErr:(NSString*)msg
{
    NSData* msgstr = [msg dataUsingEncoding:NSUTF8StringEncoding];
    [self writeToStderr:msgstr];
}

-(void)putOut:(NSString*)msg
{
    NSData* msgstr = [msg dataUsingEncoding:NSUTF8StringEncoding];
    [self writeToStdout:msgstr];
}

static void sigabort_handler(int signal, struct __siginfo* info, void * uap)
{
    //NSLog(@"sigabort_handler: signal=%d", signal);
    if( testcase_handler )
    {
        if( [testcase_handler isKindOfClass:[OpenSSLTestCase class]] )
        {
            [testcase_handler signal:(int)signal info:info];
        }
    }
}

static int fileio_stdout(void* cookie, const char * data, int len)
{
    OpenSSLTestCase* tc = (__bridge OpenSSLTestCase*)cookie;
    if( [tc isKindOfClass:[OpenSSLTestCase class]] )
    {
        NSData* dbuf = [NSData dataWithBytes:data length:len];
        [tc writeToStdout:dbuf];
    }
    return len;
}

static int fileio_stderr(void* cookie, const char * data, int len)
{
    OpenSSLTestCase* tc = (__bridge OpenSSLTestCase*)cookie;
    if( [tc isKindOfClass:[OpenSSLTestCase class]] )
    {
        NSData* dbuf = [NSData dataWithBytes:data length:len];
        [tc writeToStderr:dbuf];
    }
    return len;
}

static int fileio_read(void* cookie, char * data, int len)
{
    return len;
}

static fpos_t fileio_seek(void* cookie, fpos_t position, int where)
{
    return position;
}

static int fileio_close(void* cookie)
{
    return 0;
}

- (id)init
{
    self = [super init];
    if( self )
    {
        self.title = @"Unknown";
        self.argumentPlaceholder = @"arguments";
        in_std = *stdin;
        in_std._close = fileio_close;
        in_std._read = fileio_read;
        in_std._write = fileio_stdout;
        in_std._seek = fileio_seek;
        in_std._cookie = (__bridge void*)self;
        
        out_std = *stdout;
        out_std._close = fileio_close;
        out_std._read = fileio_read;
        out_std._write = fileio_stdout;
        out_std._seek = fileio_seek;
        out_std._cookie = (__bridge void*)self;
        
        out_err = *stderr;
        out_err._close = fileio_close;
        out_err._read = fileio_read;
        out_err._write = fileio_stderr;
        out_err._seek = fileio_seek;
        out_err._cookie = (__bridge void*)self;
        NSString* documentsFolder = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
        self.terminalOutputFileName = [documentsFolder stringByAppendingPathComponent:@"terminal.txt"];
        
    }
    return self;
}

- (void)dealloc
{
    if( arglist )
    {
        char ** pArgs = arglist;
        while( *pArgs )
            free(*pArgs++);
        free(arglist);
    }
    self.delegate = nil;
    [super dealloc];
}

- (void)viewWillAppear:(BOOL)animated
{
    if( self.title )
    {
        self.argumentString = [[NSUserDefaults standardUserDefaults] stringForKey:self.title];
        // NSLog(@"get default \"%@\"=%@", self.title, self.argumentString);
    }
}
- (void)viewWillDisappear:(BOOL)animated
{
}

+(NSArray*)parseArguments:(NSString*)inArgs
{
    NSMutableArray* rval = [NSMutableArray array];
    unichar* buf = (unichar*)malloc(1024);
    unichar* pBuf = buf;
    unsigned int length = [inArgs length];
    unsigned int index;
    
    for( index = 0; index < length; index++ )
    {
        unichar token = [inArgs characterAtIndex:index];
        // skipping white space
        if( token == ' ' || token == '\t' || token == '\n' )
            continue;
        for( ; index < length; index++ )
        {
            token = [inArgs characterAtIndex:index];
            if( token == ' ' || token == '\t' || token == '\n' )
                break;
            if( token == '\\' )
            {
                token = [inArgs characterAtIndex:++index];
                *pBuf++ = token;
                continue;
            }
            else if( token == '"' )
            {
                for( index++; index < length; index++ )
                {
                    token = [inArgs characterAtIndex:index];
                    if( token == '\\' )
                    {
                        token = [inArgs characterAtIndex:++index];
                        *pBuf++ = token;
                    }
                    else if( token == '"' )
                        break;
                    else
                        *pBuf++ = token;
                }
                break;
            }
            else
                *pBuf++ = token;
        }
        NSString* argument = [NSString stringWithCharacters:buf length:pBuf-buf];
        [rval addObject:argument];
        pBuf = buf;
    }
    return rval;
}

- (char **)args
{
    if( arglist )
    {
        char ** pArgs = arglist;
        while( *pArgs )
            free(*pArgs++);
        free(arglist);
    }
    if( self.title && self.argumentString && [self.argumentString length] )
    {
        //NSLog(@"set default \"%@\"=%@", self.title, self.argumentString);
        [[NSUserDefaults standardUserDefaults] setValue:self.argumentString forKey:self.title];
        [[NSUserDefaults standardUserDefaults] synchronize];        // because we might abort
    }
    {
        NSString* documentsFolder = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
        NSArray* list = nil;
        // if( self.argumentString && [self.argumentString length] )
        //    list = [self.argumentString componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if( self.argumentString && [self.argumentString length] )
            list = [OpenSSLTestCase parseArguments:argumentString];
        //NSLog(@"argumentString:%@, list:%@", self.argumentString, list);
        arglist = malloc(([list count] + 2) * sizeof(char *));
        arglist[0] = 0;
        unsigned int ii;
        int to;
        for( ii=0, to=0; ii<[list count]; ii++ )
        {
            NSString* arg = [list objectAtIndex:ii];
            
            if( [arg isEqualToString:@"<"] )
            {
                // handle stdin
                ii++;
                if( ii >= [list count] )
                {
                    [self putErr:[NSString stringWithFormat:@"%@ invalid stdin %@\n", self.title, self.argumentString]];
                    break;
                }
                NSString* argfile = [documentsFolder stringByAppendingPathComponent:[list objectAtIndex:ii]];
                stdin = fopen( [argfile fileSystemRepresentation], "r");
                if( !stdin )
                {
                    stdin = &in_std;
                    [self putErr:[NSString stringWithFormat:@"%@ can't open %@\n", self.title, argfile]];
                }
            }
            else if( [arg hasPrefix:@">"] )
            {
                // handle stdout
                ii++;
                if( ii >= [list count] )
                {
                    [self putErr:[NSString stringWithFormat:@"%@ invalid stdout %@\n", self.title, self.argumentString]];
                    break;
                }
                const char * openMode = "w";
                if( [arg isEqualToString:@">>"] )
                    openMode = "w+";
                NSString* argfile = [documentsFolder stringByAppendingPathComponent:[list objectAtIndex:ii]];
                stdout = fopen( [argfile fileSystemRepresentation], openMode);
                if( !stdout )
                {
                    stdout = &in_std;
                    [self putErr:[NSString stringWithFormat:@"%@ can't open %@\n", self.title, argfile]];
                }
            }
            else
                arglist[to++] = strdup([[list objectAtIndex:ii] UTF8String]);
        }
        arglist[to]=NULL;
    }
    return arglist;
}

- (int)performTest
{
    char ** argv = [self args];
    
    argv[0] = strdup([self.title UTF8String]);
    int argc;
    for( argc = 0; argv[argc]; argc++ )
        ;
    NSString* documentsFolder = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    chdir([documentsFolder fileSystemRepresentation]);
    
    [ViewController startTimer];
    // int rval = 0;
    // extern int FIPS_mode_set(int mode);
    // FIPS_mode_set(0);
    int rval = self->main_function(argc, argv);
    
    [ViewController stopTimer];

//    [self putErr:[NSString stringWithFormat:@"%s main returned %d\n",argv[0], rval]];
    return rval;
}

- (void)signal:(int)inSignal info:(struct __siginfo*)inInfo
{
    [self putErr:[NSString stringWithFormat:@"\n\n%p: SIGNAL %d\n", pthread_self(), inSignal]];
    switch( inSignal )
    {
        case SIGINT:
        case SIGQUIT:
        case SIGILL:
        case SIGTRAP:
        case SIGABRT:
        case SIGFPE:
        case SIGKILL:
        case SIGBUS:
        case SIGSEGV:
        case SIGSYS:
        {
            NSString* signalName = [NSString stringWithFormat:@"SIGNAL_%d", inSignal];
            signalName = NSLocalizedString(signalName, nil);
            [self putErr:[NSString stringWithFormat:@"\n\n%@: Test %@ aborted(%d %@).\n\n", [NSDate dateWithTimeIntervalSinceNow:0], self.title, inSignal, signalName]];
            NSError* error = [NSError errorWithDomain:NSPOSIXErrorDomain 
                                                 code:inSignal 
                                             userInfo:[NSDictionary dictionaryWithObjectsAndKeys:NSLocalizedString(@"Test Aborted", nil), NSLocalizedDescriptionKey,
                                                            signalName, NSLocalizedFailureReasonErrorKey, 
                                                            nil, nil ]
                              ];
            [self.delegate testCase:self didStop:error];
            long terminate_value=-1;
            pthread_exit(&terminate_value);
           // NSLog(@"signal:info: should never get here");
            break;
        }
        default:
            break;
    }
}

- (void)signal_handle:(BOOL)catch
{
    struct sigaction testcase_abort;
    testcase_abort.sa_mask = 0;
    if( catch )
    {
        testcase_abort.sa_sigaction = sigabort_handler;
        testcase_abort.sa_flags = SA_SIGINFO;
        testcase_handler = self;
    }
    else
    {
        testcase_abort.sa_sigaction = NULL;
        testcase_abort.sa_flags = SA_RESETHAND;
        testcase_handler = nil;
    }
    sigaction(SIGABRT, &testcase_abort, 0);
}

-(void)wasCancelled
{
    NSException* cancel = [NSException exceptionWithName:@"Test Aborted" reason:@"User cancelled" userInfo:nil];
    @throw cancel;
}

void test_cancelled(void*inArg)
{
    NSLog(@"test_cancelled: %p", inArg);
    OpenSSLTestCase* tc = (OpenSSLTestCase*)inArg;
    [tc wasCancelled];
}

- (void)invoke:(id)arg
{
    NSError* error = nil;
    int rval = 0;
    
    int save_cancelstate;
    int save_canceltype;
    
    orig_stdin = stdin;
    stdin = &in_std;
    orig_stdout = stdout;
    stdout = &out_std;
    orig_stderr = stderr;
    stderr = &out_err;
    
    stdout = stderr;    // don't know why this works...

    @try {
        pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, &save_cancelstate);
        pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, &save_canceltype);
        //pthread_cleanup_push(test_cancelled, self);
        rval = [self performTest];
        if( rval )
            error = [NSError errorWithDomain:@"OpenSSL_main" code:rval userInfo:nil];
        //pthread_cleanup_pop(0);
        pthread_setcanceltype(save_canceltype, &save_canceltype);
        pthread_setcancelstate(save_cancelstate, &save_cancelstate);
        [self putErr:[NSString stringWithFormat:@"%@ returned %d\n", self.title, rval]];
    }
    @catch (NSException *exception) {
        if( [exception.name isEqualToString:@"exit"] )
        {
            int exitval = [[[exception userInfo] objectForKey:@"exit"] intValue];
            if( exitval == 0 )    // normal completion
                error = nil;
            else
                error = [NSError errorWithDomain:@"OpenSSL_exception" code:exitval userInfo:[exception userInfo]];
        }
        else
        {
            int value = [[[exception userInfo] objectForKey:@"value"] intValue];
            error = [NSError errorWithDomain:@"OpenSSL_exception" code:value userInfo:[exception userInfo]];
        }
        if( error )
            [self putErr: [NSString stringWithFormat:@"%@ main %@: %@\n", self.title, [exception name], error]];
        else
            [self putOut:[NSString stringWithFormat:@"%@ main %@: success\n", self.title, [exception name]]];
    }
    @finally {
        [self signal_handle:NO];
        [self putOut:[NSString stringWithFormat:@"%@: Test %@ completed.\n\n", [NSDate dateWithTimeIntervalSinceNow:0], self.title]];
        [self.delegate testCase:self didStop:error];
    }
    if( stdin != &in_std && stdin != orig_stdin )
        fclose(stdin);
    stdin = orig_stdin;
    if( stdout != &out_std && stdout != orig_stdout )
        fclose(stdout);
    stdout = orig_stdout;
    if( stderr != &out_err && stderr != orig_stderr )
        fclose(stderr);
    stderr = orig_stderr;
}

void* test_invoke(void* inArg)
{
    @autoreleasepool {
        OpenSSLTestCase* tc = (OpenSSLTestCase*)inArg;
        [tc invoke:inArg];
        return NULL;
    }
}

- (void)start:(id)inDelegate withArgs:(NSString *)argString
{
    self.screenQueue = [TestMessageQueue lookupQueueWithName:@"stderr"];
    self.delegate = inDelegate;
    self.argumentString = argString;
    
    [self putOut:[NSString stringWithFormat:@"%@: Test %@ starting (%@)\n\n", [NSDate dateWithTimeIntervalSinceNow:0], self.title, argString]];
    [self signal_handle:YES];
    NSLog(@"app %s multi threaded",
          [NSThread isMultiThreaded] ? "is" : "is not");
    if( [NSThread isMultiThreaded] )
    {
        if( pthread_create(&test_thread, NULL, test_invoke, self) )
        {
            [self putErr:@"Can't start thread!"];
            NSLog(@"Can't start thread!");
        }
    }
    else
        [NSThread detachNewThreadSelector:@selector(invoke:) toTarget:self withObject:nil];
    
}

- (void)stop:(id)inDelegate
{
    self.delegate = inDelegate;
    [self putErr:[NSString stringWithFormat:@"\n\n%@: Test %@ cancelling…\n\n", [NSDate dateWithTimeIntervalSinceNow:0], self.title]];
    pthread_cancel(test_thread);
    [self signal_handle:YES];
}

- (void)logMessage:(NSString*)message
{
    [self putOut:message];
}

+ (OpenSSLTestCase*)testCaseWithName:(NSString*)testCaseName
{
    if( ! [testCaseName hasPrefix:@"OpenSSL_"] )
        testCaseName = [NSString stringWithFormat:@"OpenSSL_%@", testCaseName];
    Class tclass = NSClassFromString(testCaseName);
    OpenSSLTestCase* tcase = [[[tclass alloc] init] autorelease];
    return tcase;
}

@end


void test_case_exit(int exVal)
{
    NSDictionary* userInfo = [NSDictionary dictionaryWithObject:[NSNumber numberWithInt:exVal] forKey:@"exit"];
    [[NSException exceptionWithName:@"exit" reason:@"exit called" userInfo:userInfo] raise];
    sleep(2);
    pthread_exit(NULL);
}

int test_case_printf(const char * fmt, ... )
{
    if( testcase_handler )
    {
        va_list args;	
        va_start (args, fmt);
        NSString* msg = [[[NSString alloc] initWithFormat:[NSString stringWithUTF8String:fmt] arguments:args] autorelease];
        va_end(args);
        [testcase_handler logMessage:msg];
        // [msg release];
    }
    return 0;
}
int test_case_fprintf(FILE* fp, const char * fmt, ... )
{
    if( testcase_handler )
    {
        va_list args;	
        va_start (args, fmt);
        NSString* msg = [[[NSString alloc] initWithFormat:[NSString stringWithUTF8String:fmt] arguments:args] autorelease];
        va_end(args);
        [testcase_handler logMessage:msg];
        // [msg release];
    }
    return 0;
}

