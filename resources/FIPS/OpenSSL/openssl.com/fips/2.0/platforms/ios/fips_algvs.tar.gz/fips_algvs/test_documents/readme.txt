tv.tar.gz needs to exist here with a TV/ test data request set
