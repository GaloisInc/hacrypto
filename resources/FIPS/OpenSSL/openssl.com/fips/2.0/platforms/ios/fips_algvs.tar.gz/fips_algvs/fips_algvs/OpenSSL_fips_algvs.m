//
//  OpenSSL_fips_algvs.m
//  fips_algvs
/* ====================================================================
 * Copyright (c) 2011 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.openssl.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    openssl-core@openssl.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.openssl.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* ====================================================================
 * Copyright 2011 Thursby Software Systems, Inc. All rights reserved.
 *
 * The portions of the attached software ("Contribution") is developed by
 * Thursby Software Systems, Inc and is licensed pursuant to the OpenSSL
 * open source license.
 *
 * The Contribution, originally written by Paul W. Nelson of
 * Thursby Software Systems, Inc, consists of the fingerprint calculation
 * required for the FIPS140 integrity check.
 *
 * No patent licenses or other rights except those expressly stated in
 * the OpenSSL open source license shall be deemed granted or received
 * expressly, by implication, estoppel, or otherwise.
 *
 * No assurances are provided by Thursby that the Contribution does not
 * infringe the patent or other intellectual property rights of any third
 * party or that the license provides you with all the necessary rights
 * to make use of the Contribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. IN
 * ADDITION TO THE DISCLAIMERS INCLUDED IN THE LICENSE, THURSBY
 * SPECIFICALLY DISCLAIMS ANY LIABILITY FOR CLAIMS BROUGHT BY YOU OR ANY
 * OTHER ENTITY BASED ON INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS OR
 * OTHERWISE.
 */

#import "OpenSSL_fips_algvs.h"

    
int fips_algvs_main(int argc,char **argv);

#define main    main_fips_algvs
#define exit    test_case_exit
#define do_print_errors do_print_errors_fips_algvs
#define hex2bin hex2bin_fips_algvs
#define hex2bin_m hex2bin_m_fips_algvs
#define do_hex2bn do_hex2bn_fips_algvs
#define do_bn_print do_bn_print_fips_algvs
#define do_bn_print_name do_bn_print_name_fips_algvs
#define parse_line parse_line_fips_algvs
#define hex2bn hex2bn_fips_algvs
#define bin2hex bin2hex_fips_algvs
#define pv pb_fips_algvs
#define tidy_line tidy_line_fips_algvs
#define bint2bin bint2bin_fips_algvs
#define bin2bint bin2bint_fips_algvs
#define PrintValue PrintValue_fips_algvs
#define OutputValue OutputValue_fips_algvs
#define rsa_test rsa_test_fips_algvs
#define do_mct do_mct_fips_algvs
#define proc_file proc_file_fips_algvs
#define t_tag t_tag_fips_algvs
#define t_mode t_mode_fips_algvs

#include "test/fips_algvs.c"

@implementation OpenSSL_fips_algvs

static OpenSSL_fips_algvs* gFIPSTestSuite = nil;

- (id)init
{
    self = [super init];
    if( self )
    {
        if( gFIPSTestSuite == nil )
            gFIPSTestSuite = self;
        self.title = @"fips_algvs";
        self.argumentString = [[NSUserDefaults standardUserDefaults] stringForKey:self.title];
        self.argumentPlaceholder = @"des dsa rsa rsakey rsakeygen dsakey dsakeygen sha1 rng rngstick";
        self->main_function = main_fips_algvs;
            
    }
    return self;
}

- (void)dealloc
{
    if( gFIPSTestSuite == self )
        gFIPSTestSuite = nil;
    [super dealloc];
}

@end
