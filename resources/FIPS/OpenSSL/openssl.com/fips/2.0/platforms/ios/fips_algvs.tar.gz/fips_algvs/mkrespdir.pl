# populate ./resp/ subdirs and *.rsp file in test vector tree
use strict;
use warnings;

    for (grep m/req/, &dirlist(@ARGV) ) {
	if (-d) {	# for each ./req/ subdir make a ./resp/
		s/req$/resp/;
        	-d $_ && next;
        	print "making $_\n";
		mkdir $_ || print "error creating $_: $!\n";
	} else {	# for each *.req file make a *.rsp
		s#/req/#/resp/#;
		s/.req$/\.rsp/;
        	print "touching $_\n";
		open(FH,">$_") || print "error touching $_: $!\n";
		close(FH);
	}
    }

    my @files;
    sub dirlist {	# recurse through directory tree
        my ($root) = @_;
        $root .= '/' unless $root =~ /\/$/;
        for my $f (glob "$root*"){
            push @files, $f;
            dirlist($f) if -d $f;
        }
        return @files;
    }
