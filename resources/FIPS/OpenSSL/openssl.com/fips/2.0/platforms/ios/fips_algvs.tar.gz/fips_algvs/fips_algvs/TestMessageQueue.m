//
//  TestMessageQueue.m
//  OpenSSL_test_suite
/* ====================================================================
 * Copyright (c) 2011 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.openssl.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    openssl-core@openssl.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.openssl.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* ====================================================================
 * Copyright 2011 Thursby Software Systems, Inc. All rights reserved.
 *
 * The portions of the attached software ("Contribution") is developed by
 * Thursby Software Systems, Inc and is licensed pursuant to the OpenSSL
 * open source license.
 *
 * The Contribution, originally written by Paul W. Nelson of
 * Thursby Software Systems, Inc, consists of the fingerprint calculation
 * required for the FIPS140 integrity check.
 *
 * No patent licenses or other rights except those expressly stated in
 * the OpenSSL open source license shall be deemed granted or received
 * expressly, by implication, estoppel, or otherwise.
 *
 * No assurances are provided by Thursby that the Contribution does not
 * infringe the patent or other intellectual property rights of any third
 * party or that the license provides you with all the necessary rights
 * to make use of the Contribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. IN
 * ADDITION TO THE DISCLAIMERS INCLUDED IN THE LICENSE, THURSBY
 * SPECIFICALLY DISCLAIMS ANY LIABILITY FOR CLAIMS BROUGHT BY YOU OR ANY
 * OTHER ENTITY BASED ON INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS OR
 * OTHERWISE.
 */

#import "TestMessageQueue.h"

@implementation TestMessageView

@synthesize lastScrollTime;
@synthesize queueName;
@synthesize matchString;

- (void)testMessageQueue:(TestMessageQueue*)queue addText:(NSString*)text withFlush:(int)flush
{
    if( self.matchString )
    {
        if( [text hasPrefix:self.matchString] )
        {
            if( [self.delegate conformsToProtocol:@protocol(TestMessageMatching)] )
                [(id)self.delegate testMessageView:self didMatch:text];
        }
    }

    self.text = [self.text stringByAppendingString:text];
    if( self.lastScrollTime == nil )
        self.lastScrollTime = [NSDate dateWithTimeIntervalSinceNow:0];
    if( flush > 0 || (0-[self.lastScrollTime timeIntervalSinceNow]) > 1.0 )
    {
        NSUInteger where = [self.text length];
        if( where > 0 )
        {
            where--;
            [self scrollRangeToVisible:NSMakeRange(where, where)];
            self.lastScrollTime = [NSDate dateWithTimeIntervalSinceNow:0];
        }
    }
}

- (void)clearDisplay
{
    self.text = nil;
}

- (void)awakeFromNib
{
    //NSLog(@"TestMessageView: %@ awakeFromNib", self.queueName);
    [[TestMessageQueue lookupQueueWithName:self.queueName] setMessageView:self];
    self.matchString = nil;
}

- (void)dealloc
{
    self.matchString = nil;
    [[TestMessageQueue lookupQueueWithName:self.queueName] setMessageView:nil];
    [super dealloc];
}
@end

@implementation TestMessageQueue
@synthesize messageList = _messageList;
@synthesize messageListLock = _messageListLock;
@synthesize name;
@synthesize queueViewer;

static NSMutableArray* messageQueues = nil;

- (id)initWithName:(NSString*)inName
{
    self = [super init];
    if( self )
    {
        self.name = inName;
        if( ! messageQueues )
            messageQueues = [[NSMutableArray alloc] init];
        _messageListLock = [[NSConditionLock alloc] initWithCondition:0];
        _messageList = [[NSMutableArray alloc] init];
        [messageQueues addObject:self];
    }
    return self;
}

-(void)dealloc
{
    [messageQueues removeObjectIdenticalTo:self];
    self.messageList = nil;
    self.messageListLock = nil;
    self.name = nil;
    [super dealloc];
}

- (NSString*)description
{
    NSString* rval = [NSString stringWithFormat:@"%@(%p): %d entries", NSStringFromClass([self class]), self, self.messageList.count];
    return rval;
}

+(TestMessageQueue*)lookupQueueWithName:(NSString*)queueName
{
    TestMessageQueue* queue;
    for( queue in messageQueues )
    {
        if( [queue.name isEqualToString:queueName] )
            break;
    }
    if( !queue )
        queue = [[[TestMessageQueue alloc] initWithName:queueName] autorelease];
    return queue;
}

- (void)messageQueue:(id)inArg
{
    // NSLog(@"%@", self);
    if( self.queueViewer == nil )
        return;     // no message queue yet
    int flush;
    if( inArg )
        flush = [(NSNumber*)inArg intValue];
    else
        flush = 0;
    // we are using ARC so no pool needed
    do
    {
        //[self.messageListSignal wait];
        NSArray* newItems;
        [self.messageListLock lock];
        newItems = [self.messageList copy];
        [self.messageList removeAllObjects];
        [self.messageListLock unlock];
        id item;
        for( item in newItems )
        {
            NSString* msg = nil;
            if( [item isKindOfClass:[NSString class]] )
                msg = (NSString*)item;
            else if( [item isKindOfClass:[NSData class]] )
                msg = [[NSString alloc] initWithData:(NSData*)item encoding:NSUTF8StringEncoding];
            if( msg )
            {
                [self.queueViewer testMessageQueue:self addText:msg withFlush:flush];
                [msg release];
            }
        }
        [newItems release];
    } while( [self.messageList count] );
}

- (void)setMessageView:(TestMessageView*)view
{
    self.queueViewer = view;
    [self performSelectorOnMainThread:@selector(messageQueue:) withObject:nil waitUntilDone:YES];
}

- (void)queueMessage:(NSString*)message
{
    [self.messageListLock lock];
    [self.messageList addObject:message];
    [self.messageListLock unlock];
    [self performSelectorOnMainThread:@selector(messageQueue:) withObject:nil waitUntilDone:YES];
}

- (void)queueData:(NSData*)inData
{
    if( [inData length] <= 0 )
        return;
    [self.messageListLock lock];
    id last = [self.messageList lastObject];
    if( [last isKindOfClass:[NSMutableData class]] )
    {
        [(NSMutableData*)last appendData:inData];
    }
    else if( [inData length] == 1 )
    {
        NSMutableData* listData = [NSMutableData dataWithData:inData];
        [self.messageList addObject:listData];
    }
    else
        [self.messageList addObject:inData];
    [self.messageListLock unlock];
    if( ([inData length] > 1) || (((char*)[inData bytes])[0] == '\n') )
        [self performSelectorOnMainThread:@selector(messageQueue:) withObject:nil waitUntilDone:YES];
}

@end
