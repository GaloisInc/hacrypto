//
//  ViewController.m
//  fips_algvs
/* ====================================================================
 * Copyright (c) 2011 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.openssl.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    openssl-core@openssl.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.openssl.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* ====================================================================
 * Copyright 2011 Thursby Software Systems, Inc. All rights reserved.
 *
 * The portions of the attached software ("Contribution") is developed by
 * Thursby Software Systems, Inc and is licensed pursuant to the OpenSSL
 * open source license.
 *
 * The Contribution, originally written by Paul W. Nelson of
 * Thursby Software Systems, Inc, consists of the fingerprint calculation
 * required for the FIPS140 integrity check.
 *
 * No patent licenses or other rights except those expressly stated in
 * the OpenSSL open source license shall be deemed granted or received
 * expressly, by implication, estoppel, or otherwise.
 *
 * No assurances are provided by Thursby that the Contribution does not
 * infringe the patent or other intellectual property rights of any third
 * party or that the license provides you with all the necessary rights
 * to make use of the Contribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. IN
 * ADDITION TO THE DISCLAIMERS INCLUDED IN THE LICENSE, THURSBY
 * SPECIFICALLY DISCLAIMS ANY LIABILITY FOR CLAIMS BROUGHT BY YOU OR ANY
 * OTHER ENTITY BASED ON INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS OR
 * OTHERWISE.
 */

#import "ViewController.h"
#import "OpenSSLTestCase.h"
#import <sys/time.h>

struct timeval sgStartTime = {0,0};

@interface ViewController ()

@end

@implementation ViewController
@synthesize args;
@synthesize go;
@synthesize elapsedTime;
@synthesize updateTimer;
@synthesize output;
@synthesize testCase;

static ViewController* sgViewController = nil;

-(void)reportError:(NSError*)inError targetFile:(NSString*)inTarget
{
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSString* defaultArgs = [[NSUserDefaults standardUserDefaults] objectForKey:@"arguments"];
    if( !defaultArgs )
        defaultArgs = @"fips_algvs fips_test_suite";
    self.args.text = defaultArgs;
    
    if( self.output.delegate == (id)self )
        self.output.matchString = @"Running command line:";
    
    NSString* documentsFolder = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSArray *bundleDocs = [[NSBundle mainBundle] pathsForResourcesOfType:nil inDirectory:@"test_documents"];
    if( bundleDocs && bundleDocs.count )
    {
        NSString* initialItem;
        for( initialItem in bundleDocs )
        {
            NSString *dstPath = [documentsFolder stringByAppendingPathComponent:[initialItem lastPathComponent]];
            
            if( ![[NSFileManager defaultManager] fileExistsAtPath:dstPath] )
            {
                NSError* copyError;
                
                if( ![[NSFileManager defaultManager] copyItemAtPath:initialItem toPath:dstPath error:&copyError] )
                {
                    [self reportError:copyError targetFile:dstPath];
                }
            }
        }
    }
    chdir([documentsFolder fileSystemRepresentation]);
    
	// Do any additional setup after loading the view, typically from a nib.
    sgViewController = self;
    self.updateTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateView) userInfo:nil repeats:YES];
}

- (void)viewDidUnload
{
    [self.updateTimer invalidate];
    self.updateTimer = nil;
    sgViewController = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

-(void)testMessageView:(TestMessageView*)view didMatch:(NSString*)matching;
{
    testcount++;
}

-(void)updateView
{
    if( sgStartTime.tv_sec == 0 && sgStartTime.tv_usec == 0 )
    {
        // do nothing, the time display does not need updating
    }
    else
    {
        struct timeval tnow;
        gettimeofday(&tnow, NULL);
        struct timeval tdelta;
        
        timersub(&tnow, &sgStartTime, &tdelta);
        
        long minutes = tdelta.tv_sec / 60;
        tdelta.tv_sec -= (minutes * 60);
        int seconds = tdelta.tv_sec;
        self.elapsedTime.text = [NSString stringWithFormat:@"%ld - %ld:%2.2d", testcount, minutes, seconds];
    }
}

-(void)elapsedTime:(BOOL)start
{
    if( start )
    {
        gettimeofday(&sgStartTime, NULL);
    }
    else {
        sgStartTime.tv_sec = 0;
        sgStartTime.tv_usec = 0;
    }
}

+(void)startTimer
{
    [sgViewController elapsedTime:YES];
}
+(void)stopTimer
{
    [sgViewController elapsedTime:NO];
}

- (void)testCase:(OpenSSLTestCase*)test didStop:(NSError*)error
{
    [self.go setTitle:@"Go" forState:UIControlStateNormal];
    NSLog(@"testCase didStop");
    [self elapsedTime:NO];
    if( error )
    {
        
    }
    self.testCase = nil;
}

-(IBAction)goPressed:(id)sender
{
    NSString* script = self.args.text;
    
    if(args)
        [args resignFirstResponder];
    
    if( self.testCase )
    {
        exit(1);
    }
    else if( script && script.length )
    {
        testcount = 0;
        [[NSUserDefaults standardUserDefaults] setObject:script forKey:@"arguments"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        NSArray* arguments = [OpenSSLTestCase parseArguments:script];
        if( arguments && arguments.count > 0 )
        {
            self.testCase = [OpenSSLTestCase testCaseWithName:[arguments objectAtIndex:0]];
            if( self.testCase )
            {
                [self.go setTitle:@"Abort" forState:UIControlStateNormal];
                [self.testCase start:self withArgs:script];
            }
        }
    }
}
@end
