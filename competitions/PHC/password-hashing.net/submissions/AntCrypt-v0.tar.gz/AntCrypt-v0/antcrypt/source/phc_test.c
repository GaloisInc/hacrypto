/* used to limit the test */
#define MAX 100000

void test() {
/*
	int i,j;
	int x;
	int sum, s, sum_max;
	unsigned int values[MAX];

	srand ( time(NULL) );

	// write values
	for (i = 0; i < MAX; i++) {
		x = rand();
		values[i] = F(x);
	}

	// test multiplicity
	sum = 0;
	sum_max = 0;
	for (i = 0; i < MAX; i++) {
		s = 0;
		for (j = 0; j < MAX; j++) {
			if (values[i] == values[j]) { 
				s++;
			}
		}
		sum += s;
		if (s > sum_max) {
			sum_max = s;
		}
	}
	*/

	//print values
	/*
	   for(i=0; i<MAX; i++){
	   printf("%08x  ", values[i]);
	   if(i%8 == 7){ printf("\n"); }
	   }
	   */
	/*
	printf("\n\n");
	printf("sum = %i, sum_avg = %f, sum_max = %i\n", sum, (float)sum/MAX, sum_max);
	*/
}

