Lanarea Cover Sheet
===================

Submitted Scheme Name:	Lanarea DF
Casual Name:		Lanarea

Author's Name:		Haneef Mubarak
Author's Email:		haneef503@gmail.com

-------------------------------------------

GPG Signing Keys:

keyserver:				hkp://keys.gnupg.net
key used to sign repository commits:	F08280A4 <haneefmubarak@users.noreply.github.com>

-------------------------------------------

Description of Files:

LanareaDF.pdf		Lanarea Paper
build.sh		Build Script (tested on OSX Lion and Ubuntu Saucy)
lanarea.c		Lanarea implementation
lanarea.h		Lanarea header
libb2/			BLAKE2 library
test.c			Lanarea test vectors 0-255
