Algorithm Name: MCSSHA-8
Principal Submitter: Mikhail Maslennikov
Revision: 17.02.2014 


mcssha8 code

\mcssha8.cpp  
       Source code (ANSI C programming language) for MCSSHA-8 hash algorithm

\mcssha8.h
     Header file for mcssha8.cpp

\mcssha8_macros.h
     Header file for mcssha8 macros (ANSI C programming language) 

\makefile 
     File for compile 

\README.txt
      this file

All files for 32 and 64 bits compiler.     
