Algorithm Name: MCS_PSW
Principal Submitter: Mikhail Maslennikov
Revision: 17.02.2014 


mcs_psw code

\mcs_psw.cpp  
       Source code (ANSI C programming language) for MCS_PSW scheme algorithm

\mcs_psw.h
     Header file for mcs_psw.cpp

\makefile 
     File for compile 

\README.txt
      this file

All files for 32 and 64 bits compiler.     
