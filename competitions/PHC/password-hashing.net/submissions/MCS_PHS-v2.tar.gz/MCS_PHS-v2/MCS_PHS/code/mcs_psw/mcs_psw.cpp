//# Algorithm Name: MCS_PSW
//# Principal Submitter: Mikhail Maslennikov
//# Revision: 08.08.2014 

#include <stdio.h>
#include <memory.h>
#include <windows.h>
#include "mcs_psw.h"
#include "../mcssha8/mcssha8.h"

// MCS password hashing scheme (MCS_PHS)
int PHS(void *out, size_t outlen, const void *in, size_t inlen, const void *salt, size_t saltlen, unsigned int t_cost, unsigned int m_cost)
{
	 DWORD dwErr = 0;
	 BYTE *tmp = NULL; //temprorary memory for MCS_PHS
	 unsigned int i = 0;
	 unsigned int mcost = DEFAULT_M_COST_BYTE;

//Parameters control
		if(
			out == NULL                       ||
			outlen == 0                       ||
			outlen > MAX_HASH_SIZE_BYTE       || 
			( in == NULL && inlen != 0 )      || 
			( salt == NULL && saltlen != 0 )   
			) 
			return NTE_BAD_DATA;
		 

		if(m_cost != 0)
			mcost = m_cost;

		if(mcost < saltlen + inlen + 2)
			return NTE_BAD_LEN; 
		int tmp_size = mcost;
		if(tmp_size < MAX_HASH_SIZE_BYTE)tmp_size = MAX_HASH_SIZE_BYTE; // if MAX_HASH_SIZE > m_cost && m_cost != 0

// Allocate tmp memory

		if((tmp = (BYTE *)malloc(tmp_size)) == NULL)
			return ERROR_NOT_ENOUGH_MEMORY;

// Preparing temprorary memory

		tmp[0] = (BYTE)inlen;  // Password length (to protect from password's length attack)

		if(inlen != 0)memcpy(tmp + 1,in,inlen); // add password

		tmp[inlen + 1] = (BYTE)saltlen;

		if(saltlen != 0)memcpy(tmp + inlen + 2 ,salt,saltlen); // add salt
		 
		for(i = (unsigned int)saltlen + (unsigned int)inlen + 2; i < mcost; i++)tmp[i] = i; // add auxiliary bytes


// First hashing using MCSSHA-8. Hash length = 64 bytes 
		if(Hash(MAX_HASH_SIZE_BIT,tmp,mcost<<3,tmp))
		{
			free(tmp);
			return NTE_BAD_HASH;
		}
// Main hash cycle. Each step reduces the length of the hash on 1 from 64 to outlen bytes.
		for( i = MAX_HASH_SIZE_BYTE - 1; i >= outlen; i--)
		{
			if(Hash(i<<3,tmp,(i+1)<<3,tmp))
			{
				free(tmp);
				return NTE_BAD_HASH;
			}
		}

// If t_cost != 0 perform additional cycle.
		if(t_cost)
		{
			for(i = 0; i < t_cost; i++)
			{
				if(Hash(outlen<<3,tmp,outlen<<3,tmp))
				{
					free(tmp);
					return NTE_BAD_HASH;
				}
			}
		}

// Perform final computation for protect against attack in 5.1 (PBKDF1) from Frances F. Yao and Yiqun Lisa Yin "Design and Analysis of Password-Based Key Derivation Functions"

	if(outlen != MAX_HASH_SIZE_BYTE)
	{
		if(Hash(MAX_HASH_SIZE_BIT,tmp,outlen<<3,tmp) || Hash(outlen<<3,tmp,MAX_HASH_SIZE_BIT,tmp))
		{
			free(tmp);
			return NTE_BAD_HASH;
		}
	}
	else
	{
		for(i = 0; i < MAX_HASH_SIZE_BYTE; i++)tmp[i] += (BYTE)i;
		if(Hash(MAX_HASH_SIZE_BIT,tmp,MAX_HASH_SIZE_BIT,tmp))
		{
			free(tmp);
			return NTE_BAD_HASH;
		}

	}

// Final hash for password
	memcpy(out,tmp,outlen);



	 free(tmp);



	 return ERROR_SUCCESS;
}