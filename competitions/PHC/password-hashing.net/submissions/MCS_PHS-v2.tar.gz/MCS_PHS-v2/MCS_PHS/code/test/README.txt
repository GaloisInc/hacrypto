Algorithm Name: Test for MCS_PSW
Principal Submitter: Mikhail Maslennikov
Revision: 17.02.2014 


test code

\test.cpp  
       Source code (ANSI C programming language) for test

\stdafx.h
     Header file for test.cpp

\makefile 
     File for compile 

\README.txt
      this file

All files for 32 and 64 bits compiler.     
