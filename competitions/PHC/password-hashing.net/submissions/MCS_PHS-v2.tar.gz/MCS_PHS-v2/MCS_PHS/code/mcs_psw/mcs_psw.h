//# Algorithm Name: MCS_PSW
//# Principal Submitter: Mikhail Maslennikov
//# Revision: 25.05.2014 

#ifndef HEADER_MCS_PSW_H
#define HEADER_MCS_PSW_H

#define MAX_HASH_SIZE_BIT    512
#define MAX_HASH_SIZE_BYTE   64
#define DEFAULT_M_COST_BYTE  256

int PHS(void *out, size_t outlen, const void *in, size_t inlen, const void *salt, size_t saltlen, unsigned int t_cost, unsigned int m_cost);



#endif	
