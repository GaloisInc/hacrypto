Algorithm Name: MCS_PSW
Principal Submitter: Mikhail Maslennikov
Revision: 08.08.2014 


How to use MCS_PSW package.

1) Type "make" for prepare libraries and testing program. 
   Should appear the following files:

	- lib/mcssha8.o - MCSSHA8 hash algorithm static library;
	
	- lib/mcs_psw.o - MCS_PSW scheme static library;

	- bin/test.exe  - testing program executable file.

2) Rename TotalTests.~bat to TotalTests.bat

3) Start TotalTests.bat. Results will be in "results" folder

	  