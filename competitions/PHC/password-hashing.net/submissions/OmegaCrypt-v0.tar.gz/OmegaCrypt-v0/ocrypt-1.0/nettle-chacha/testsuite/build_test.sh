clang -Wall -O2 -o test-chacha test-chacha.c ../chacha-core-internal.c ../chacha-crypt.c ../chacha-init.c ../memxor.c -I../
