package org.bouncycastle.crypto.tls;

public interface TlsCredentials
{
    Certificate getCertificate();
}
