package org.bouncycastle.crypto.tls;

public class ChangeCipherSpec
{
    public static final short change_cipher_spec = 1;
}
