package org.bouncycastle.crypto.tls;

public abstract class AbstractTlsCredentials
    implements TlsCredentials
{
}
