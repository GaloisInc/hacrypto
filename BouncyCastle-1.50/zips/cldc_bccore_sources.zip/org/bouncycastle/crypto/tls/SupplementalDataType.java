package org.bouncycastle.crypto.tls;

/**
 * RFC 4680
 */
public class SupplementalDataType
{
    /*
     * RFC 4681
     */
    public static final int user_mapping_data = 0;
}
