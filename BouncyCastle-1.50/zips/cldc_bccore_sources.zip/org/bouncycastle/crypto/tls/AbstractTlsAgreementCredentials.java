package org.bouncycastle.crypto.tls;

public abstract class AbstractTlsAgreementCredentials
    extends AbstractTlsCredentials
    implements TlsAgreementCredentials
{
}
